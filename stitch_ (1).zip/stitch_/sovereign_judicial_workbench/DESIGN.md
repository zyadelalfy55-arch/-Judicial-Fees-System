---
name: Sovereign Judicial Workbench
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45464d'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#775a00'
  on-secondary: '#ffffff'
  secondary-container: '#fece57'
  on-secondary-container: '#735700'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#00164e'
  on-tertiary-container: '#6780d3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#ffdf98'
  secondary-fixed-dim: '#eec14b'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#5a4300'
  tertiary-fixed: '#dce1ff'
  tertiary-fixed-dim: '#b6c4ff'
  on-tertiary-fixed: '#00164e'
  on-tertiary-fixed-variant: '#264191'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  sovereign-gold-light: '#E8BE4B'
  sovereign-gold-dark: '#9B771A'
  institutional-navy-deep: '#0A1120'
  slate-surface: '#F8FAFC'
  slate-surface-elevated: '#FFFFFF'
  border-subtle: '#E2E8F0'
  border-strong: '#CBD5E1'
  status-verified: '#14532D'
  status-verified-bg: '#F0FDF4'
  status-return: '#881337'
  status-return-bg: '#FFF1F2'
  status-pending: '#854D0E'
  status-pending-bg: '#FEFCE8'
  derivation-blue: '#1E40AF'
  derivation-blue-bg: '#EFF6FF'
typography:
  display-hero:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: '0'
  display-hero-mobile:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: '0'
  headline-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: '0'
  headline-lg-mobile:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: '0'
  headline-md:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: '0'
  headline-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: '0'
  title-base:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: '0'
  body-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: '0'
  body-base:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  body-sm:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: '0'
  stat-currency:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  label-lg:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 22px
    letterSpacing: '0'
  label-base:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-legal:
    fontFamily: IBM Plex Sans Arabic
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

### Brand Personality & Emotional Tone
This design system defines an authoritative, sovereign, and precision-driven judicial operations workbench for the Egyptian Ministry of Justice. Crafted specifically for judicial fee officers, legal auditors, presiding judges, and judicial administrators, the interface projects unquestioned institutional legitimacy, calm impartiality, and mathematical certitude. The visual cadence rejects flashy B2B SaaS tropes, marketing fluff, decorative illustrations, and hyper-saturated gradients in favor of solemn administrative dignity and pristine legibility.

### Design Movement: Modern Sovereign Institutionalism
The design marries the rigorous clarity of modern administrative design with sovereign Egyptian judicial emblems. It uses:
- High typographic contrast and pristine structural borders over heavy drop shadows.
- Dedicated spatial zones calibrated strictly for Arabic-first Right-to-Left (RTL) cognitive flow.
- Explainability-first architecture: calculations never present ungrounded numbers; they visually structure raw facts, derivations, statutory conditions, legal citations, and mathematical proofs.
- Uncompromising whitespace disciplines: screen density is handled through progressive disclosure, clear step models, and dedicated multi-tab workspaces rather than compressed type scales.

## Colors

### Sovereign Palette Hierarchy
The palette derives directly from the official emblem of the Egyptian Ministry of Justice: deep executive charcoal navy symbolizing sovereign state authority, accented by prestigious Egyptian ochre gold symbolizing the scales of justice and sovereign balance.

- **Primary (`#0F172A`)**: Executive Sovereign Charcoal Slate. Serves as the primary operational anchor, deep headers, top-tier navigation bars, and primary text contrast.
- **Secondary (`#C59B27`) & Gold Accent (`#9B771A`)**: Sovereign Egyptian Gold. Deployed intentionally on official seal accents, verified badge borders, active stepper indices, focus highlights, and key legal authorization markers.
- **Tertiary (`#1E3A8A`)**: Judicial Derivation Cobalt. Applied to mathematical logic indicators, calculation formulas, dynamic step progress tracks, and reference citations.
- **Neutrals & Canvas (`#F8FAFC`, `#FFFFFF`, `#64748B`)**: Pure, glare-free architectural canvas backgrounds. Structural boundaries use muted slate borders (`#E2E8F0`, `#CBD5E1`) without visual clutter.

### Semantic Status Governance
Judicial determination must be unmistakable. Status is never communicated via color alone; color tokens are paired with explicit state badges and high-contrast typography:
- **Verified / Approved (`#14532D` on `#F0FDF4`)**: Forest Green token for reconciled balances and officially stamped decisions.
- **Returns / Corrections (`#881337` on `#FFF1F2`)**: Deep Burgundy token for defective submissions, missing court fees, or clerical adjustments.
- **Pending Review (`#854D0E` on `#FEFCE8`)**: Amber-Muted Gold token for items currently seated in the fee officer or review judge queue.
- **Derivation & Calculation Steps (`#1E40AF` on `#EFF6FF`)**: Cobalt Blue for dynamic fees, base percentages, and derived statutory deductions.

## Typography

### Arabic-First Cognitive Hierarchy
The typography is anchored exclusively by `IBM Plex Sans Arabic`, chosen for its balance between formal governmental authority and technical precision. Its calligraphic baseline avoids letterform clipping and cramped Arabic diacritics.

### Governance Rules
- **No Shrinking to Fit**: Visual density issues must never be resolved by shrinking type below standard thresholds. Data density must instead be resolved using progressive disclosure panels, statutory accordions, and tabbed divisions.
- **RTL Fluidity**: Text alignment is strictly `right-to-left` throughout all views. Digits used within financial tallies and legal case numbers are rendered with uniform width tabular lining to ensure flawless column alignment in fee ledgers.
- **Explainability Display (`stat-currency`)**: Final calculation outputs feature distinct numeric emphasis paired directly with the statutory currency sign (جنيه مصري / EGP), elevated at 32px bold to eliminate clerical misreading.

## Layout & Spacing

### Shell & Layout Blueprint
The application operates on an asymmetrical, high-stability Desktop Split Shell:
- **Navigation Anchor (Sidebar - Right side in RTL)**: Fixed width 280px deep slate anchor containing institutional insignia, jurisdictional breadcrumbs, and primary role routing.
- **Main Operational Canvas (Left side in RTL)**: Fluid grid with a strict maximum bound of 1600px, structured along an immutable vertical rhythm: `Breadcrumb Bar → Judicial Action Header → Workflow Stepper → Modular Explainability Canvas → Action Docket Bar`.

### Responsive Breakpoints & Reflow
- **Desktop (1280px+)**: 12-column grid, 1.5rem (`gutter`) columns, 2rem (`margin`) canvas margins. Side-by-side verification: Input Form (7 columns) alongside live calculation proof breakdown (5 columns).
- **Compact Desktop / Tablet Landscape (1024px – 1279px)**: 8-column layout, 1rem gutter. The explainability breakdown docks below the form or collapses into an accordion drawer.
- **Tablet Portrait & Mobile (Below 1024px)**: 4-column layout, 1rem margin. Sidebar transforms into a sovereign drawer; stepper indicators shift from horizontal ribbon to numbered modal stepper. Nested scroll bars within panes are banned.

## Elevation & Depth

### Institutional Low-Elevation Philosophy
The system eschews multi-layered glassy overlays, saturated drops, and distracting skeuomorphism. Depth is produced via crisp architectural boundary lines and restrained, tinted slate underlays.

### Surface Tiers
1. **Base Foundation (Level 0)**: Background canvas (`#F8FAFC`), entirely flat and non-reflective.
2. **Elevated Document Card (Level 1)**: Primary judicial work surface (`#FFFFFF`). Defined by a 1px solid border (`#E2E8F0`) paired with a faint ambient shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`.
3. **Interactive & Active Containers (Level 2)**: Verification panels, statutory rule blocks, and active dynamic steps. Outlined in `#CBD5E1` with shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`.
4. **Focused Statutory Overlays & Confirmations (Level 3)**: Limited strictly to sovereign authorization dialogs and critical clerical warnings. Framed with a 1px `#9B771A` accent outline and elevated by `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.08)`.

## Shapes

### Shape Language & Geometry
The geometry is clean, solemn, and architectural (`roundedness: 1` — Soft). Sharp angles represent administrative discipline, tempered with micro-radii to ensure ease of reading on retina and non-retina judicial workstations.

- **Inputs, Buttons, and Badges**: 0.25rem (`4px`) corner radius. Maintains structured formality and grid alignment across high-volume docket inputs.
- **Cards, Rule Blocks, and Accordions**: 0.5rem (`8px`) corner radius (`rounded-lg`). Provides distinct separation between administrative stages without creating bubbly or casual consumer-app shapes.
- **Modals and Explainability Panels**: 0.75rem (`12px`) corner radius (`rounded-xl`).
- **Pills**: Strictly reserved for non-interactive state badges and official verification stamps.

## Components

### Buttons
- **Primary Sovereign Button**: `#0F172A` fill with `#FFFFFF` text, subtle 1px border (`#1E293B`), 4px corner radius. Hover shifts to `#1E293B` with a crisp 1px gold bottom accent (`#C59B27`). Focus ring: 2px solid `#C59B27` with 2px offset.
- **Secondary / Action Button**: `#FFFFFF` background, 1px solid `#CBD5E1`, text `#0F172A`. Hover transitions background to `#F8FAFC` and border to `#94A3B8`.
- **Destructive / Return Button**: Deep burgundy `#881337` text with `#FFF1F2` background, transitioning to full `#881337` fill with white text for critical actions.

### Form Inputs & Selectors
- Visible 1px border (`#CBD5E1`) over `#FFFFFF` canvas. 
- Field height: 42px for dense scanning without clerical strain. 
- Text aligns right with the mandatory asterisk (`*`) placed on the right side of the Arabic label text. 
- Focus state: Border transitions to `#0F172A` with a 2px outer sovereign gold glow (`#C59B27` at 20% opacity).

### Status Badges & Stamps
- Compact inline containers with 4px or pill geometry, pairing an explicit textual status label with a 6px solid dot marker.
- Text must explicitly state the status (e.g., `تم التحقق والاعتماد`, `معلق للمراجعة`, `مسترجع للتعديل`). Never use standalone color chips.

### Explainability Calculation Cards
- Purpose-built cards separating the math trail:
  1. **Raw Case Input (`البيانات المدخلة`)**: Clean tabular presentation.
  2. **Statutory Derivations (`القيم المشتقة`)**: Cobalt border highlight with formula badges.
  3. **Applied Rule & Legal Article (`القاعدة المختارة والأساس القانوني`)**: Framed in a light ochre container (`#FEFCE8`) referencing the specific decree or code article.
  4. **Final Judicial Total (`إجمالي الرسوم المستحقة`)**: Prominent `#0F172A` bar, bold currency typography, accompanied by official verification action buttons.

### Tabular Judicial Ledgers
- Clean, bordered ledger rows with alternate row striping (`#FFFFFF` to `#F8FAFC`).
- High-contrast headers in `#0F172A` with bold Arabic labels.
- Numerical fee columns right-aligned with fixed tabular numbers for immediate audit scanning.